﻿package sample3;

public interface UserService {
	public void addUser(UserVo vo);
}
