package exam1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class GreetingTest {

	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("exam1/greeting.xml");
		
		Greeting bean=factory.getBean("morning",Greeting.class);
		System.out.println(bean.toString());

	}

}
