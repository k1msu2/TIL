﻿package sample4;

public class Saturday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "Saturday";
	}
}