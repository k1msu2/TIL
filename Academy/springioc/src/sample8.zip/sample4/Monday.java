﻿package sample4;


public class Monday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "Monday";
	}
}
