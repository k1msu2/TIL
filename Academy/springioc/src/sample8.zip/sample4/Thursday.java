﻿package sample4;

public class Thursday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "Thursday";
	}
}