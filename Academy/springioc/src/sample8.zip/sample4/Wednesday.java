﻿package sample4;

public class Wednesday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "Wednesday";
	}
}
