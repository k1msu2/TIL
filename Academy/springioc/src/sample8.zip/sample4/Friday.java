﻿package sample4;

public class Friday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "금요일 입니다";
	}
}