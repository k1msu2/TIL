﻿package sample6;

import java.io.IOException;

public interface Outputter {
	public void output(String message) throws IOException;
}







