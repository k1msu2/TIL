﻿package sample6;

public interface MessageBean {
	public void helloCall();
}
