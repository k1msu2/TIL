﻿package sample2;
//아무것도 없어도 인터페이스임..
public interface InterFoo {

}
