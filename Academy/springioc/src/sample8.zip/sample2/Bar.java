﻿package sample2;

public class Bar {
	public Bar() {
		System.out.println("Bar - Create object");
	}
}
